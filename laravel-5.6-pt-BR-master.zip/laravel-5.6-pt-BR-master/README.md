# Laravel 5.6 - Português do Brasil

Veja o tutorial completo de como traduzir as mensagens, rotas e models no link: [https://blog.oiprogramador.com.br/traduzir-laravel-5-6-para-portugues-do-brasil-dicas-laravel-1/](https://blog.oiprogramador.com.br/traduzir-laravel-5-6-para-portugues-do-brasil-dicas-laravel-1/)
